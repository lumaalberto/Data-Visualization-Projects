# Assignment: Week I and II

# Name: Luma, Alberto

# Import the Hotdog contest winners data
hotdog_contest_winners<- read.delim(file.choose(), header=T, sep=",")
# Attach the data
attach(hotdog_contest_winners)

dim(hotdog_contest_winners)

names(hotdog_contest_winners)

#creating bar chart
barplot(Dogs.eaten, main = "Hotdog Contest Winners-Country-Bar Chart", xlab = "Winners", ylab = "Hotdogs")

#creating pie chart
count<- table(Country)
pie(count, main = "Hotdog Contest Winners-Country-Bar Chart", col = 1:4)

#creating Stacked bar chart
hotdog_table<- table(Dogs.eaten, Country)
barplot(hotdog_table, beside = TRUE, main = "Hotdog Contest Winners-Country-Bar Chart", xlab = "Countries", ylab = "Hotdogs Eaten", col = 1:4, las=3)


# Import the Hotdog places data
hotdog_places<- read.delim(file.choose(), header=T, sep=",")
# Attach the data
attach(hotdog_places)

dim(hotdog_places)

names(hotdog_places)

count1<- table(Year_2000, Year_2005, Year_2010)
count1

#creating bar chart
barplot(Year...2000, main = "Hotdog Places 2000")
barplot(Year...2005, main = "Hotdog Places 2005")
barplot(Year...2010, main = "Hotdog Places 2010")

#creating pie chart
pie(Year...2000, main = "Hotdog Places 2000", col = 1:4)
pie(Year...2005, main = "Hotdog Places 2005", col = 1:4)
pie(Year...2010, main = "Hotdog Places 2010", col = 1:4)

#creating Stacked bar chart
hotdog_table1<- table(Year...2000)
barplot(Year...2000, Year...2005, Year...2010, beside = TRUE, main = "Hotdog Places")



# Import the obama approval ratings
obama_approval_ratings<- read.delim(file.choose(), header=T, sep=",")
# Attach the data
attach(obama_approval_ratings)

dim(obama_approval_ratings)

names(obama_approval_ratings)


#creating bar chart
barplot(Approve, main = "Obama - Approve Rate", xlab = "Issue", ylab = "Approve")
barplot(Disapprove, main = "Obama - Diapprove Rate", xlab = "Issue", ylab = "Disapprove")
barplot(None, main = "Obama - None Rate", xlab = "Issue", ylab = "None")

#creating pie chart
pie(Approve, main = "Approve", col = 1:7)
pie(Disapprove, main = "Disapprove", col = 1:7)
pie(None, main = "None", col = 1:7)

#creating Stacked bar chart
Approval_Rate<- table(Approve, Disapprove, None)
barplot(Approve, Disapprove, None, beside = TRUE, main = "Approval Rate")

